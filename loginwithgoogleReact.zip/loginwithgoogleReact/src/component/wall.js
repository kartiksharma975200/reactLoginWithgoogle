import React, { Component } from 'react';
import Header from './header';

class Wall extends Component {
  constructor(props){
     super(props);
     this.state={
         postList:JSON.parse(localStorage.getItem('allPost'))
     }
   }
   componentDidMount(){
    // if(!localStorage.getItem("userData")){
    //    window.location.href="/";
    // }
    const postList=JSON.parse(localStorage.getItem('allPost'));
    this.setState({postList});
  }

  render() {
      console.log('post',this.state.postList);
    return (
      <div className="container">
          <Header />
          {this.state.postList && this.state.postList && this.state.postList.length>0 ? 
             <div className="row">
                 {this.state.postList.map((post,i)=>(
                <div className="col-md-8 col-md-offset-2 postdiv" key={i}>
                    <div className="row">
                        <div className="col-md-3">
                            <img src={post.postBy.imageUrl} className="img img-responsive img-circle" style={{'width':'100px'}} />
                        </div>
                        <div className="col-md-9">
                           <p className="postdetails">{post.post}</p>
                           <p className="postMeta"><b>Post By :</b> {post.postBy.name} </p>
                           <p className="postMeta"><b>Post Date :</b> {post.postDate}</p>
                           
                           
                        </div>
                    </div>
                </div>
                )) }
             </div>
            : <p>No Post </p>}
      </div>
    );
  }
}

export default Wall;
