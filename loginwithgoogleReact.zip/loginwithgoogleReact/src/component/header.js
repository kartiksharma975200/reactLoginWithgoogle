import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { GoogleLogout } from 'react-google-login';

class Header extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            isLogin: 0
        }

    }
    componentDidMount() {
        if (localStorage.getItem("userData")) {
            this.setState({ isLogin: 1 })
        }
    }
    logout() {
        localStorage.removeItem('userData');
        window.location.href='/';
    }
    render() {
        return (
            <div className="">
                <nav className="navbar navbar-default">
                    <div className="container-fluid">
                        <div className="navbar-header">
                            <Link className="navbar-brand" to="/">WebSiteName</Link>
                        </div>
                        <ul className="nav navbar-nav">
                            {this.state.isLogin === 1 ? <li><Link to="/profile">Profile</Link></li>
                                : ''}
                            <li><Link to="/wall">Post List</Link></li>
                            {this.state.isLogin === 1 ?
                                <li><GoogleLogout buttonText="Logout" clientId="815450097849-ollr7cuj88fbtvnrlr7t2j2vrq4daehj.apps.googleusercontent.com" onLogoutSuccess={this.logout}  >
                                </GoogleLogout></li>
                                : ''}

                        </ul>
                    </div>
                </nav>
            </div>
        );
    }
}

export default Header;
