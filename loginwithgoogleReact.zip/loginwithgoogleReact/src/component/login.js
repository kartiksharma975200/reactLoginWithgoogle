import React, { Component } from 'react';
import GoogleLogin from 'react-google-login';
import { BrowserRouter as Router, Route, Link ,Switch } from "react-router-dom";
import LoginPage from './loginPage';
import Profile from './profile';
import Wall from './wall';
import '../App.css';

class Login extends Component {
  
  render() {
    return (
      <div className="App">
          <Router>
              <Switch>
                <Route exact path="/" component={LoginPage} />
                <Route exact path="/profile" component={Profile} />
                <Route exact path="/wall" component={Wall} />
               </Switch>
          </Router>
           
      </div>
    );
  }
}

export default Login;
