import React, { Component } from 'react';
import Header from './header';
import { Redirect } from "react-router-dom";


class Profile extends Component {
    
  constructor(props){
     super(props);
     this.state={
         userProfile:'',
         post:'',
         error:'',
         success:'',
     };
     this.handleChange = this.handleChange.bind(this);
   }
   componentDidMount(){
    if(!localStorage.getItem("userData")){
      this.props.history.push('/');
    }
    const userProfile=JSON.parse(localStorage.getItem("userData"));
    this.setState({userProfile});
    
  }
  formSubmit(){
      if(this.state.post && this.state.post.length>0){
        const error="";
        this.setState({error});
        const formData={
            post:this.state.post,
            postBy:this.state.userProfile,
            postDate:Date()
        };
        var postList=[];
        this.setState({post:''})
        const success="Post add Success";
          this.setState({success});
        if(localStorage.getItem("allPost")){
            var postList=JSON.parse(localStorage.getItem("allPost"));
        }
        postList.push(formData);
        localStorage.setItem("allPost",JSON.stringify(postList));
      }else{
          const error="Please Enter Post Value";
          this.setState({error});
          const success="";
          this.setState({success});
          
      }

  }
  handleChange(event){
     this.setState({post:event.target.value})
  }
  render() {
    
     return (
      <div className="container">
           <Header />
          <div className="row">
             <div className="col-md-4 col-sm-6 col-xs-12">
                 <div className="row">
                    <div className="wall">
                       {this.state && this.state.userProfile  ?
                        <div >
                           <img src={this.state.userProfile.imageUrl} className="img img-responsive img-circle" />
                           <ul className="profileData">
                               <li>{this.state.userProfile.name}</li>
                               <li>{this.state.userProfile.email}</li>
                               <li>{this.state.userProfile.googleId}</li>
                           </ul>
                        </div>
                      :
                        <div>Loding .. </div>   
                      }
                    </div>
                 </div>
             </div>
             <div className="col-md-8 col-sm-6 col-xs-12">
                 <div className="row">
                    <h3>Post Form</h3>
                    <div className="col-md-12">
                      <div className="form-group">
                      {this.state.success && this.state.success.length>0 ? 
                             <p className="alert alert-success">{this.state.success}</p>
                            :''}
                        <form method="post" >
                           <label>Post Title</label>
                           <input type="text" className="form-control" value={this.state.post} onChange={this.handleChange} />
                           {this.state.error && this.state.error.length>0 ? 
                             <p className="text text-danger">{this.state.error}</p>
                            :''}
                           <br/>
                           <a className="btn btn-info" onClick={()=>this.formSubmit()}>Post</a>
                        </form>
                          
                      </div>
                    </div>
                 </div>
             </div>
          </div>
       
      </div>
    );
  }
}

export default Profile;
