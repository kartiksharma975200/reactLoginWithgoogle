import React, { Component } from 'react';
import GoogleLogin from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
import Header from './header';


class LoginPage extends Component {
  constructor(props){
     super(props);
     this.responseSuccess=this.responseSuccess.bind(this)
   }
  componentDidMount(){
    if (localStorage.getItem("userData")) {
      this.props.history.push('/profile');
    }
  }
	responseSuccess(a){
         console.log('res',a);
         localStorage.setItem("userData",JSON.stringify(a.profileObj));
         
         this.props.history.push('/profile');
        
   }
  responseFail(a){
    console.log('res',a);
    }
  render() {
   
    return (
      <div className="container">
         <Header />
        <GoogleLogin
    clientId="815450097849-ollr7cuj88fbtvnrlr7t2j2vrq4daehj.apps.googleusercontent.com"
    buttonText="Login"
    onSuccess={this.responseSuccess}
    onFailure={this.responseFail}
  />
 
      </div>

    );
  }
}

export default LoginPage;
